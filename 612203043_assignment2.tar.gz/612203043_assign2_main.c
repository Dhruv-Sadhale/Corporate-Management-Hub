#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>
#include "612203043_assign2.c"



int main(){
	
	tree t;
	int size;
	printf("Enter maximum number of nodes:\n");
	scanf("%d",&size);
	int value=0;
	init_bst(&t,size);
	printf("Enter non-negative integer(enter -1 to exit)\n");
	while(value!=-1){
		scanf("%d", &value);
		insert_bst(&t, value);
	}
	
	printf("Inorder traversal:\n");
	inorder(&t);
	printf("Postorder traversal:\n");
	postorder(&t);
	printf("Preorder traversal:\n");
	preorder(&t);
	levelwise(&t);
	int x=isComplete(&t);
	if(x)
	printf("It is a complete tree\n");
	else
	printf("It is not a complete tree\n");
	return 0;
}
