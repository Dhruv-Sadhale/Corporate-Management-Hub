#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>

#define SIZE 100
#define MAX_SIZE 100
typedef struct tree{
	int *arr;
	int size;
}tree;
typedef struct stack{
	int *a;
	int size;
	int top;
}stack;

typedef struct Node {
    int data;
    struct Node* next;
} Node;

typedef struct {
    Node* front;
    Node* rear;
} queue;
void qinit(queue* q) ;
int qempty(queue q) ;
void enq(queue* q, int data) ;
int deq(queue* q) ;
void init(stack *ptr, int size);
int isempty(stack s);
int isfull(stack s);
void push(stack *ptr, int data);
int pop(stack *ptr);
void init_bst(tree* t, int size);
void insert_bst(tree *t, int data) ;
void inorder(tree *t);
void postorder(tree *t);
void preorder(tree *t);
void levelwise(tree *t);
int isComplete(tree *t);


