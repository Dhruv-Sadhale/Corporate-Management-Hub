#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>
#include "612203043_assign2.h"

void qinit(queue* q) {
    q->front = q->rear = NULL;
}

int qempty(queue q) {
    return (q.front == NULL);
}

void enq(queue* q, int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;

    if (q->rear == NULL) {
        q->front = q->rear = newNode;
        return;
    }

    q->rear->next = newNode;
    q->rear = newNode;
}

int deq(queue* q) {
    if (qempty(*q)) {
        return INT_MIN;
    }

    Node* temp = q->front;
    int data = temp->data;

    q->front = temp->next;

    if (q->front == NULL) {
        q->rear = NULL;
    }

    free(temp);

    return data;
}
void init(stack *ptr, int size){
	ptr->a=(int*)malloc(sizeof(int)*size);
	ptr->size=size;
	ptr->top=-1;
}
int isempty(stack s){
	return (s.top==-1);
}
int isfull(stack s){
	return (s.top==s.size-1);
}
void push(stack *ptr, int data){
	if (isfull(*ptr))
		return;
	ptr->top++;
	ptr->a[ptr->top]=data;
}
int pop(stack *ptr){
	if(isempty(*ptr))
		return INT_MIN;
	return ptr->a[ptr->top--];
}
void init_bst(tree* t, int size)
{
	t->arr=(int*)malloc(sizeof(int)*size);
	t->size=size;
	for(int i=0;i<t->size;i++){
		t->arr[i]=-1;
	}
}
void insert_bst(tree *t, int data) {
    int i = 0;
    int flag = 0;
    
    while (i < t->size) {
        if (t->arr[i] == -1) {
            flag = 1;
            break;
        } else if (data > t->arr[i]) {
            i = 2 * i + 2;
        } else if (data < t->arr[i]) {
            i = 2 * i + 1;
        }
    }

    if (flag == 1 && i < t->size) {
        t->arr[i] = data;
        
    } else {
        printf("Error: BST is full\n");
    }
}

void inorder(tree *t){
	stack a;
	init(&a,SIZE);
	int store=0;
	int flag=1;
	while(store<t->size && flag){
		if(t->arr[store]!=-1){
			push(&a,store);
			store=2*store+1;
		}
		else{
			if(!isempty(a)){
				store=pop(&a);
				printf("%d | ", t->arr[store]);
				store=2*store+2;
			}
			else{
				flag=0;
			}
		}
	}
	printf("\n");
}
void postorder(tree *t){
	stack a,b;
	int store=0;
	init(&a,SIZE);
	init(&b,SIZE);
	push(&a,store);
	while(!isempty(a)){
		store=pop(&a);
		push(&b,store);
		if((2*store+1)<t->size && t->arr[2*store+1]!=-1)
			push(&a,2*store+1 );
		if((2*store+2)<t->size && t->arr[2*store+2]!=-1)
			push(&a,2*store+2);
	}
	while(!isempty(b))
		printf("%d | ", t->arr[pop(&b)]);
	printf("\n");
}
void preorder(tree *t){
	stack a;
	init(&a, SIZE);
	int store=0;
	int flag=1;
	if(t->arr[store]==-1){
		return;
	}
	int k=1;
	while(flag){
		if(t->arr[store]!=-1 && k!=0){
			printf("%d | ", t->arr[store]);
			push(&a, store);
			if(t->arr[2*store+1] !=-1)
				store=2*store+1;
			else k=0;
		}
		else{
			if(!isempty(a)){
				store=pop(&a);
				if(t->arr[2*store+2] != -1){
					store=2*store+2;
					k=1;
				}
			}
			else flag=0;
		}
	}
}
void levelwise(tree *t){
    queue q;
    qinit(&q);
    int store = 0;
    enq(&q, store);
    printf("\nLevelwise\n");

    while(!qempty(q)) {
        store = deq(&q);

        if (t->arr[store] != -1) {
            printf("%d ", t->arr[store]);

            if ((2 * store + 1) < t->size && t->arr[2 * store + 1] != -1)
                enq(&q, 2 * store + 1);
            
		
            if ((2 * store + 2) < t->size && t->arr[2 * store + 2] != -1)
                enq(&q, 2 * store + 2);
        }
    }
    printf("\n");
}
int isComplete(tree *t){
	int in=0, out=0;
	for(int i=0;i<t->size;i++){
		if(t->arr[i]!=-1){
			if(out==0){
				in=1;
			}
			else{
				return 0;
			}
		}
		
		else{
			out=1;
		}
	}
	return 1;
}
